package cobratest

import (
	_ "github.com/spf13/cobra"

	"log"
	"testing"
)

func TestCorbra(t *testing.T) {
	log.Println("111")
}
