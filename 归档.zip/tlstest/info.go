package tlstest

import "fmt"

var (
	Port = 11201
	ConnectAddr = "127.0.0.1:"+fmt.Sprintf("%v",Port)
)
